#import <Cocoa/Cocoa.h>


@interface FontNameTransformer : NSValueTransformer {

}

@end
