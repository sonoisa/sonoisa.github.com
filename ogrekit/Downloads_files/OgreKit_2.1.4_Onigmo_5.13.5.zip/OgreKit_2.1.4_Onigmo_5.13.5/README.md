![image](http://sonoisa.github.com/ogrekit/About_%28English%29_files/OgreKitLogo.gif)

#OgreKit
-- OniGuruma Regular Expression Framework for Cocoa --

* **Japanese Site:** http://sonoisa.github.com/ogrekit/About.html
* **English Site:** http://sonoisa.github.com/ogrekit/About_%28English%29.html
