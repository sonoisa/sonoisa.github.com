#import <Cocoa/Cocoa.h>

@interface Controller : NSObject

@end
